import React from 'react';
import BooksList from './components/BooksList';
import AddBook from './components/AddBook';
import LoansList from './components/LoansList';
import CreateLoan from './components/CreateLoan';

function App() {
  return (
    <div>
      <h1>Library Management System</h1>
      <AddBook />
      <BooksList />
      <CreateLoan />
      <LoansList />
    </div>
  );
}

export default App;
