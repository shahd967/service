import React, { useEffect, useState } from 'react';
import { getLoans } from '../api'; // API functions

const LoansList = () => {
  const [loans, setLoans] = useState([]);

  useEffect(() => {
    getLoans()
      .then(response => setLoans(response.data))
      .catch(error => console.error('Error fetching loans:', error));
  }, []);

  return (
    <div>
      <h2>Active Loans</h2>
      <ul>
        {loans.map((loan) => (
          <li key={loan._id}>
            Loaned to User: {loan.userId} for Book ID: {loan.bookId} | Due Date: {loan.returnDate ? loan.returnDate : 'N/A'}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default LoansList;
