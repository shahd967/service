import React, { useEffect, useState } from 'react';
import { getBooks } from '../api'; // API functions

const BooksList = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    getBooks()
      .then(response => setBooks(response.data))
      .catch(error => console.error('Error fetching books:', error));
  }, []);

  return (
    <div>
      <h2>Books List</h2>
      <ul>
        {books.map((book) => (
          <li key={book._id}>
            {book.title} by {book.author} ({book.genre})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BooksList;
