import React, { useState } from 'react';
import axios from 'axios';

const AddBook = () => {
  const [bookData, setBookData] = useState({
    title: '',
    author: '',
    publishedDate: '',
    genre: '',
    availableCopies: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBookData({ ...bookData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Send data to the backend
    axios.post('http://localhost:5000/books', bookData)
      .then(response => {
        console.log('Book added:', response.data);
      })
      .catch(error => {
        console.error('There was an error adding the book!', error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" name="title" value={bookData.title} onChange={handleInputChange} placeholder="Title" required />
      <input type="text" name="author" value={bookData.author} onChange={handleInputChange} placeholder="Author" required />
      <input type="date" name="publishedDate" value={bookData.publishedDate} onChange={handleInputChange} required />
      <input type="text" name="genre" value={bookData.genre} onChange={handleInputChange} placeholder="Genre" required />
      <input type="number" name="availableCopies" value={bookData.availableCopies} onChange={handleInputChange} placeholder="Available Copies" required />
      <button type="submit">Add Book</button>
    </form>
  );
};

export default AddBook;
