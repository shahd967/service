import axios from 'axios';

// Set up base URLs for each microservice
const api = axios.create({
  baseURL: 'http://localhost:3001/', // Adjust according to your microservices port (for example, book service at 3001)
});

export const getBooks = () => api.get('/books');
export const createBook = (data) => api.post('/books', data);
export const updateBook = (id, data) => api.put(`/books/${id}`, data);
export const deleteBook = (id) => api.delete(`/books/${id}`);

export const getLoans = () => api.get('/loans');
export const createLoan = (data) => api.post('/loans', data);
export const updateLoan = (id, data) => api.put(`/loans/${id}`, data);
export const deleteLoan = (id) => api.delete(`/loans/${id}`);
