import React, { useState } from 'react';
import { createLoan } from '../api';

const CreateLoan = () => {
  const [userId, setUserId] = useState('');
  const [bookId, setBookId] = useState('');
  const [loanDate, setLoanDate] = useState('');
  const [returnDate, setReturnDate] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newLoan = {
      userId,
      bookId,
      loanDate,
      returnDate,
    };

    createLoan(newLoan)
      .then(response => {
        console.log('Loan created:', response.data);
        // Optionally clear form fields
        setUserId('');
        setBookId('');
        setLoanDate('');
        setReturnDate('');
      })
      .catch(error => console.error('Error creating loan:', error));
  };

  return (
    <div>
      <h2>Create New Loan</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>User ID:</label>
          <input type="text" value={userId} onChange={(e) => setUserId(e.target.value)} />
        </div>
        <div>
          <label>Book ID:</label>
          <input type="text" value={bookId} onChange={(e) => setBookId(e.target.value)} />
        </div>
        <div>
          <label>Loan Date:</label>
          <input type="date" value={loanDate} onChange={(e) => setLoanDate(e.target.value)} />
        </div>
        <div>
          <label>Return Date:</label>
          <input type="date" value={returnDate} onChange={(e) => setReturnDate(e.target.value)} />
        </div>
        <button type="submit">Create Loan</button>
      </form>
    </div>
  );
};

export default CreateLoan;
